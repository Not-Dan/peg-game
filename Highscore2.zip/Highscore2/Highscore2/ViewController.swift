//
//  ViewController.swift
//  Highscore2
//
//  Created by CSUApple MacBooks on 11/28/16.
//  Click count button and score will increase with highscore. 
//  click reset and score = 0 and highscore remains the same until
//  score increases past highscore
//  code in counterAction and viewDidLoad will store highscore
//  I suggest we remove highscore board add a lable to the game that
//  records the fastest completed time

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var scoreLbl: UILabel!
    @IBOutlet weak var highscoreLbl: UILabel!
    
    var score = 0
    var highscore = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //will load storred value
        var HighscoreDefault = NSUserDefaults.standardUserDefaults()
        if (HighscoreDefault.valueForKey("Highscore") != nil) {
        highscore = HighscoreDefault.valueForKey("Highscore") as! NSInteger
        highscoreLbl.text = String(format: "%i", highscore)
            scoreLbl.text = String(format: "%i", score)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func resetAction(sender: AnyObject) {
        score = 0
        scoreLbl.text = String(format: "%i", score)
    }
    
    @IBAction func counterAction(sender: AnyObject) {
        score++
        scoreLbl.text = String(format: "%i", score)
        if (score > highscore) {
            highscore = 0 //score
            highscoreLbl.text = String(format: "%i", highscore)
            
            //access core data and store highscore
            var HighscoreDefault = NSUserDefaults.standardUserDefaults()
            HighscoreDefault.setValue(highscore, forKey: "Highscore")
            HighscoreDefault.synchronize()
        }
    }
}
/* Stack Overflow to high score solution????????
// Read the high score from the user defaults at app startup.
high_score = [NSUserDefaults blah blah]; // read from user defaults

// Run the game

if ( game_score > high_score )
{
// this is a new high score, update the internal variable...
high_score = game_score;

// ...and write out the new high score to user defaults
[NSUserDefaults blah blah]; // write to user defaults
}
*/