//
//  GameViewController.swift
//  
//
//  Created by CISAPP13 on 11/23/16.
//
//

import UIKit

class GameViewController: UIViewController {
    //color vars
    let grayImg = UIImage(named: "gray")
    let greenImg = UIImage(named: "green")
    let redImg = UIImage(named: "red")
    let blueImg = UIImage(named: "blue")
    
    var lastTouched: Int = 0
    var pinCount: Int = 14
    var firstClick: Bool = false
    var counter = Float(0.0)
    var timer = NSTimer()
    

    @IBOutlet var pegLabel: UILabel!
    @IBOutlet var elapsedTimeLabel: UILabel!
//pegs -Left to right, top to bottom
    
    //first row
    @IBOutlet var one: UIButton!
    
    //second row
    @IBOutlet var two: UIButton!
    @IBOutlet var three: UIButton!
    
    //third row
    @IBOutlet var four: UIButton!
    @IBOutlet var five: UIButton!
    @IBOutlet var six: UIButton!
    
    //fourth row
    @IBOutlet var seven: UIButton!
    @IBOutlet var eight: UIButton!
    @IBOutlet var nine: UIButton!
    @IBOutlet var ten: UIButton!
    
    //bottom row
    @IBOutlet var eleven: UIButton!
    @IBOutlet var twelve: UIButton!
    @IBOutlet var thirteen: UIButton!
    @IBOutlet var fourteen: UIButton!
    @IBOutlet var fifteen: UIButton!
    
    @IBAction func clickReset(sender: AnyObject) {
        reset()
    }
    
    //reset
    func reset() {
        
        pinCount = 14
        counter = 0
        
        pegLabel.text = "Pegs Remaining: \(pinCount)"
        
        one.setImage(grayImg, forState: UIControlState.Normal)
        two.setImage(redImg, forState: UIControlState.Normal)
        three.setImage(redImg, forState: UIControlState.Normal)
        four.setImage(redImg, forState: UIControlState.Normal)
        five.setImage(redImg, forState: UIControlState.Normal)
        six.setImage(redImg, forState: UIControlState.Normal)
        seven.setImage(redImg, forState: UIControlState.Normal)
        eight.setImage(redImg, forState: UIControlState.Normal)
        nine.setImage(redImg, forState: UIControlState.Normal)
        ten.setImage(redImg, forState: UIControlState.Normal)
        eleven.setImage(redImg, forState: UIControlState.Normal)
        twelve.setImage(redImg, forState: UIControlState.Normal)
        thirteen.setImage(redImg, forState: UIControlState.Normal)
        fourteen.setImage(redImg, forState: UIControlState.Normal)
        fifteen.setImage(redImg, forState: UIControlState.Normal)
        
    }
    
    // click
    @IBAction func clickMove(sender: AnyObject){
        //what to do per click
        
        //I think there is an easier way yto do this, but this way is just tedious
        //write code to check potential moves
        if firstClick == false && sender.currentImage == redImg {
            if sender as! NSObject == one{
                //we have to hardcode every possibility for each button press
                one.setImage(greenImg, forState: UIControlState.Normal)
                if two.currentImage == redImg && four.currentImage == grayImg{
                    four.setImage(blueImg, forState: UIControlState.Normal)
                }
                if three.currentImage == redImg && six.currentImage == grayImg{
                    six.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 1
            }
            if sender as! NSObject == two{
                two.setImage(greenImg, forState: UIControlState.Normal)
                if four.currentImage == redImg && seven.currentImage == grayImg{
                    seven.setImage(blueImg, forState: UIControlState.Normal)
                }
                if five.currentImage == redImg && nine.currentImage == grayImg{
                    nine.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 2
            }
            if sender as! NSObject == three{
                three.setImage(greenImg, forState: UIControlState.Normal)
                if five.currentImage == redImg && eight.currentImage == grayImg{
                    eight.setImage(blueImg, forState: UIControlState.Normal)
                }
                if six.currentImage == redImg && ten.currentImage == grayImg{
                    ten.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 3
            }
            if sender as! NSObject == four{
                four.setImage(greenImg, forState: UIControlState.Normal)
                if two.currentImage == redImg && one.currentImage == grayImg{
                    one.setImage(blueImg, forState: UIControlState.Normal)
                    
                }
                if five.currentImage == redImg && six.currentImage == grayImg{
                    six.setImage(blueImg, forState: UIControlState.Normal)
                    
                }
                if eight.currentImage == redImg && thirteen.currentImage == grayImg{
                    thirteen.setImage(blueImg, forState: UIControlState.Normal)
                    
                }
                if seven.currentImage == redImg && eleven.currentImage == grayImg{
                    eleven.setImage(blueImg, forState: UIControlState.Normal)
                    
                }
                lastTouched = 4
            }
            if sender as! NSObject == five {
                five.setImage(greenImg, forState: UIControlState.Normal)
                if eight.currentImage == redImg && twelve.currentImage == grayImg{
                    twelve.setImage(blueImg, forState: UIControlState.Normal)
                }
                if nine.currentImage == redImg && fourteen.currentImage == grayImg{
                    fourteen.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 5
            }
            if sender as! NSObject == six{
                //we have to hardcode every possibility for each button press
                six.setImage(greenImg, forState: UIControlState.Normal)
                if three.currentImage == redImg && one.currentImage == grayImg{
                    one.setImage(blueImg, forState: UIControlState.Normal)
                    
                }
                if five.currentImage == redImg && four.currentImage == grayImg{
                    four.setImage(blueImg, forState: UIControlState.Normal)
                    
                }
                if nine.currentImage == redImg && thirteen.currentImage == grayImg{
                    thirteen.setImage(blueImg, forState: UIControlState.Normal)
                    
                }
                if ten.currentImage == redImg && fifteen.currentImage == grayImg{
                    fifteen.setImage(blueImg, forState: UIControlState.Normal)
                    
                }
                lastTouched = 6
            }
            if sender as! NSObject == seven {
                seven.setImage(greenImg, forState: UIControlState.Normal)
                if four.currentImage == redImg && two.currentImage == grayImg{
                    two.setImage(blueImg, forState: UIControlState.Normal)
                }
                if eight.currentImage == redImg && nine.currentImage == grayImg{
                    nine.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 7
            }
            if sender as! NSObject == eight {
                eight.setImage(greenImg, forState: UIControlState.Normal)
                if five.currentImage == redImg && three.currentImage == grayImg{
                    three.setImage(blueImg, forState: UIControlState.Normal)
                }
                if nine.currentImage == redImg && ten.currentImage == grayImg{
                    ten.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 8
            }
            if sender as! NSObject == nine {
                nine.setImage(greenImg, forState: UIControlState.Normal)
                if five.currentImage == redImg && two.currentImage == grayImg{
                    two.setImage(blueImg, forState: UIControlState.Normal)
                }
                if eight.currentImage == redImg && seven.currentImage == grayImg{
                    seven.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 9
            }
            if sender as! NSObject == ten {
                ten.setImage(greenImg, forState: UIControlState.Normal)
                if nine.currentImage == redImg && eight.currentImage == grayImg{
                    eight.setImage(blueImg, forState: UIControlState.Normal)
                }
                if six.currentImage == redImg && three.currentImage == grayImg{
                    three.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 10
            }
            if sender as! NSObject == eleven {
                eleven.setImage(greenImg, forState: UIControlState.Normal)
                if seven.currentImage == redImg && four.currentImage == grayImg{
                    four.setImage(blueImg, forState: UIControlState.Normal)
                }
                if twelve.currentImage == redImg && thirteen.currentImage == grayImg{
                    thirteen.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 11
            }
            if sender as! NSObject == twelve {
                twelve.setImage(greenImg, forState: UIControlState.Normal)
                if eight.currentImage == redImg && five.currentImage == grayImg{
                    five.setImage(blueImg, forState: UIControlState.Normal)
                }
                if thirteen.currentImage == redImg && fourteen.currentImage == grayImg{
                    fourteen.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 12
            }
            if sender as! NSObject == thirteen {
                thirteen.setImage(greenImg, forState: UIControlState.Normal)
                if twelve.currentImage == redImg && eleven.currentImage == grayImg{
                    eleven.setImage(blueImg, forState: UIControlState.Normal)
                }
                if eight.currentImage == redImg && four.currentImage == grayImg{
                    four.setImage(blueImg, forState: UIControlState.Normal)
                }
                if nine.currentImage == redImg && six.currentImage == grayImg{
                    six.setImage(blueImg, forState: UIControlState.Normal)
                }
                if fourteen.currentImage == redImg && fifteen.currentImage == grayImg{
                    fifteen.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 13
            }
            if sender as! NSObject == fourteen {
                fourteen.setImage(greenImg, forState: UIControlState.Normal)
                if nine.currentImage == redImg && five.currentImage == grayImg{
                    five.setImage(blueImg, forState: UIControlState.Normal)
                }
                if thirteen.currentImage == redImg && twelve.currentImage == grayImg{
                    twelve.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 14
            }
            if sender as! NSObject == fifteen {
                fifteen.setImage(greenImg, forState: UIControlState.Normal)
                if ten.currentImage == redImg && six.currentImage == grayImg{
                    six.setImage(blueImg, forState: UIControlState.Normal)
                }
                if fourteen.currentImage == redImg && thirteen.currentImage == grayImg{
                    thirteen.setImage(blueImg, forState: UIControlState.Normal)
                }
                lastTouched = 15
            }
            firstClick = true
        }

        //this happens when you click on a blue one
        else if sender.currentImage == blueImg && firstClick{
            sender.setImage(redImg, forState: UIControlState.Normal)
            var current: Int = 0
            if sender as! NSObject == one{
                current = 1
            }
            if sender as! NSObject == two{
                current = 2
            }
            if sender as! NSObject == three{
                current = 3
            }
            if sender as! NSObject == four{
                current = 4
            }
            if sender as! NSObject == five{
                current = 5
            }
            if sender as! NSObject == six{
                current = 6
            }
            if sender as! NSObject == seven{
                current = 7
            }
            if sender as! NSObject == eight{
                current = 8
            }
            if sender as! NSObject == nine{
                current = 9
            }
            if sender as! NSObject == ten{
                current = 10
            }
            if sender as! NSObject == eleven{
                current = 11
            }
            if sender as! NSObject == twelve{
                current = 12
            }
            if sender as! NSObject == thirteen{
                current = 13
            }
            if sender as! NSObject == fourteen{
                current = 14
            }
            if sender as! NSObject == fifteen{
                current = 15
            }
            pinMove(current)
            pinCount--
            //get rid of remaining blue pins
            
            //write code to change all blue pins back to red
            removeBlueGreen()
            firstClick = false
            
        }
        
        if sender.currentImage == redImg && firstClick {
            removeBlueGreen()
            firstClick = false
            clickMove(sender)
        }
        
        
        //win function
        if pinCount == 1 {
            let alert = UIAlertController(title: "Winner!", message: "You Won! Press reset to start over.", preferredStyle: UIAlertControllerStyle.Alert)
        }
        
        pegLabel.text = "Pegs Remaining: \(pinCount)"
    }
    
    func removeBlueGreen(){
        //change blue to gray
        if one.currentImage == blueImg{
            one.setImage(grayImg, forState: UIControlState.Normal)
        }
        if two.currentImage == blueImg{
            two.setImage(grayImg, forState: UIControlState.Normal)
        }
        if three.currentImage == blueImg{
            three.setImage(grayImg, forState: UIControlState.Normal)
        }
        if four.currentImage == blueImg{
            four.setImage(grayImg, forState: UIControlState.Normal)
        }
        if five.currentImage == blueImg{
            five.setImage(grayImg, forState: UIControlState.Normal)
        }
        if six.currentImage == blueImg{
            six.setImage(grayImg, forState: UIControlState.Normal)
        }
        if seven.currentImage == blueImg{
            seven.setImage(grayImg, forState: UIControlState.Normal)
        }
        if eight.currentImage == blueImg{
            eight.setImage(grayImg, forState: UIControlState.Normal)
        }
        if nine.currentImage == blueImg{
            nine.setImage(grayImg, forState: UIControlState.Normal)
        }
        if ten.currentImage == blueImg{
            ten.setImage(grayImg, forState: UIControlState.Normal)
        }
        if eleven.currentImage == blueImg{
            eleven.setImage(grayImg, forState: UIControlState.Normal)
        }
        if twelve.currentImage == blueImg{
            twelve.setImage(grayImg, forState: UIControlState.Normal)
        }
        if thirteen.currentImage == blueImg{
            thirteen.setImage(grayImg, forState: UIControlState.Normal)
        }
        if fourteen.currentImage == blueImg{
            fourteen.setImage(grayImg, forState: UIControlState.Normal)
        }
        if fifteen.currentImage == blueImg{
            fifteen.setImage(grayImg, forState: UIControlState.Normal)
        }
        
        //change green back to red
        if one.currentImage == greenImg{
            one.setImage(redImg, forState: UIControlState.Normal)
        }
        if two.currentImage == greenImg{
            two.setImage(redImg, forState: UIControlState.Normal)
        }
        if three.currentImage == greenImg{
            three.setImage(redImg, forState: UIControlState.Normal)
        }
        if four.currentImage == greenImg{
            four.setImage(redImg, forState: UIControlState.Normal)
        }
        if five.currentImage == greenImg{
            five.setImage(redImg, forState: UIControlState.Normal)
        }
        if six.currentImage == greenImg{
            six.setImage(redImg, forState: UIControlState.Normal)
        }
        if seven.currentImage == greenImg{
            seven.setImage(redImg, forState: UIControlState.Normal)
        }
        if eight.currentImage == greenImg{
            eight.setImage(redImg, forState: UIControlState.Normal)
        }
        if nine.currentImage == greenImg{
            nine.setImage(redImg, forState: UIControlState.Normal)
        }
        if ten.currentImage == greenImg{
            ten.setImage(redImg, forState: UIControlState.Normal)
        }
        if eleven.currentImage == greenImg{
            eleven.setImage(redImg, forState: UIControlState.Normal)
        }
        if twelve.currentImage == greenImg{
            twelve.setImage(redImg, forState: UIControlState.Normal)
        }
        if thirteen.currentImage == greenImg{
            thirteen.setImage(redImg, forState: UIControlState.Normal)
        }
        if fourteen.currentImage == greenImg{
            fourteen.setImage(redImg, forState: UIControlState.Normal)
        }
        if fifteen.currentImage == greenImg{
            fifteen.setImage(redImg, forState: UIControlState.Normal)
        }
    }
    
    //last touch emulator ~DONE
    //will record the last touch, and change the button color to emulate moving the pin
    func pinMove(currentPin: Int) {
        if lastTouched == 1 {
            one.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 4 {
                two.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 6 {
                three.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 2 {
            two.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 7 {
                four.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 9 {
                five.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 3 {
            three.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 8 {
                five.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 10 {
                six.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 4 {
            four.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 1 {
                two.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 6 {
                five.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 13 {
                eight.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 11 {
                seven.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 5 {
            five.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 12 {
                eight.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 14 {
                nine.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 6 {
            six.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 1 {
                three.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 4 {
                five.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 13 {
                nine.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 15 {
                ten.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 7 {
            seven.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 2 {
                four.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 9 {
                eight.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 8 {
            eight.setImage(grayImg, forState: UIControlState.Normal)
            
            if currentPin == 3 {
                five.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 10 {
                nine.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 9 {
            nine.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 2 {
                five.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 7 {
                eight.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 10 {
            ten.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 3 {
                six.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 8 {
                nine.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 11 {
            eleven.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 4 {
                seven.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 13 {
                twelve.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 12 {
            twelve.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 14 {
                thirteen.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 5 {
                eight.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 13 {
            thirteen.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 11 {
                twelve.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 15 {
                fourteen.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 4 {
                eight.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 6 {
                nine.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 14 {
            fourteen.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 12 {
                thirteen.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 5 {
                nine.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
        if lastTouched == 15 {
            fifteen.setImage(grayImg, forState: UIControlState.Normal)
            if currentPin == 13 {
                fourteen.setImage(grayImg, forState: UIControlState.Normal)
            }
            if currentPin == 6 {
                ten.setImage(grayImg, forState: UIControlState.Normal)
            }
        }
    }
    
    func timeCount() {
        counter += Float(0.1)
        var rounded = String(format: "%.1f", counter)
        elapsedTimeLabel.text = "Elapsed Time: \(rounded)"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        //initialize game        
        one.setImage(grayImg, forState: UIControlState.Normal)
        two.setImage(redImg, forState: UIControlState.Normal)
        three.setImage(redImg, forState: UIControlState.Normal)
        four.setImage(redImg, forState: UIControlState.Normal)
        five.setImage(redImg, forState: UIControlState.Normal)
        six.setImage(redImg, forState: UIControlState.Normal)
        seven.setImage(redImg, forState: UIControlState.Normal)
        eight.setImage(redImg, forState: UIControlState.Normal)
        nine.setImage(redImg, forState: UIControlState.Normal)
        ten.setImage(redImg, forState: UIControlState.Normal)
        eleven.setImage(redImg, forState: UIControlState.Normal)
        twelve.setImage(redImg, forState: UIControlState.Normal)
        thirteen.setImage(redImg, forState: UIControlState.Normal)
        fourteen.setImage(redImg, forState: UIControlState.Normal)
        fifteen.setImage(redImg, forState: UIControlState.Normal)
        
        var timer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: "timeCount", userInfo: nil, repeats: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
