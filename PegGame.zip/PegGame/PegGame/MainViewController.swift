//
//  MainViewController.swift
//  
//
//  Created by CISAPP13 on 11/27/16.
//
//

import UIKit

class MainViewController: UIViewController {
    let startImg = UIImage(named: "start")
    let midImg = UIImage(named: "middle")
    let endImg = UIImage(named: "win")
    
    @IBOutlet var sliderImage: UIImageView!
    
    
    var timer: NSTimer?
    var counter = 0
    func startTimer()
    {
        if timer == nil {
            timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: "timeCount", userInfo: nil, repeats: true)
        }
    }
    
    func timeCount(){
        counter++
        if counter < 5 {
            sliderImage.image = startImg
        }else if counter >= 5 && counter < 10 {
            sliderImage.image = midImg
        }
        else if counter >= 10 && counter < 15 {
            sliderImage.image = endImg
        }
        else {
            counter = 0
        }
    }
    
    override
    func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        startTimer()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
